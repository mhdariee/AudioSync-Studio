# Status rilis 2.1.0-rc.1

**HOLD — kandidat privat untuk peninjauan, bukan rilis publik yang disertifikasi.**

Pengujian Windows bersih (VM/Sandbox tanpa Python/model/cache pengembang) belum selesai. Lingkungan pengembang yang diisolasi tetap bukan pengganti Windows bersih. Jalankan tests/CLEAN_WINDOWS.md dan simpan bukti sebelum mengganti status ini.

Installer belum ditandatangani dengan sertifikat penerbit. Python embedded 3.11.9 adalah versi kompatibilitas, bukan patch keamanan terbaru. Jalur pembaruan runtime perlu diverifikasi sebelum rilis stabil. Tidak ada TTS Indonesia otomatis; impor audio tetap tersedia. Tidak ada jaminan matching benar, alignment kata Indonesia, format proyek native CapCut, atau CUDA.

Tidak ada publikasi GitHub/Threads yang diizinkan oleh pembuatan kandidat ini. Setelah seluruh blocker selesai, pemilik tetap harus meninjau dan menyetujui artefak akhir dan lisensinya.
