# Validasi kandidat 2.1.0-rc.1

Status: kandidat privat untuk peninjauan, belum disertifikasi untuk distribusi umum.

## Bukti yang tersedia

Pengujian dilakukan di komputer pengembang Windows menggunakan runtime Python embedded baru yang diunduh dari Python.org, 113 artefak dependensi yang dikunci dengan SHA-256, model bahasa spaCy, FFmpeg dari mirror resmi, dan 37 berkas model/suara dengan revisi serta hash terverifikasi. Virtualenv pribadi tidak digunakan sebagai runtime aplikasi publik. Instalasi pribadi tetap terpisah; 32 berkas sumber awal yang dijadikan referensi diperiksa ulang dan hash-nya tidak berubah. Proyek/media pribadi tidak dimasukkan ke distribusi.

| Pemeriksaan | Hasil |
|---|---|
| Installer EXE pada folder uji baru | Lulus, exit code 0 |
| Menolak tujuan yang berisi aplikasi lama tanpa penanda edisi publik | Lulus, exit code 7; fixture asli tetap utuh |
| Shortcut, ikon, direktori kerja dan server hasil installer | Lulus; health endpoint lokal merespons ok di port terpisah |
| Setup komponen pertama dan pengulangan setup | Lulus; pip check tidak menemukan dependensi rusak |
| Unit, kontrak impor, UI dan pemulihan | 32 tes lulus pada runtime hasil instalasi |
| Narasi Inggris nyata dan ekspor CapCut campuran gambar/video | Lulus |
| Regenerasi per kalimat dan impor WAV/MP3 Indonesia | Lulus; fixture Indonesia berupa nada sintetis untuk menguji alur, bukan kualitas pelafalan Indonesia |
| Alignment akustik, pergeseran jeda satu detik, kamera gambar dan bypass video | Lulus |
| Subtitle none / separate / burn, optional ASS dan preview | Lulus; frame, audio, file dan ZIP diperiksa |
| Matching gambar bernama acak, skrip Inggris/Indonesia, cache dan konfirmasi | Lulus pada tiga fixture bentuk berwarna; bukan tolok ukur akurasi foto umum |
| Suara perempuan offline | WAV 24 kHz valid, durasi 2,525 detik |
| Matching dan CapCut saat koneksi nonlokal ditolak oleh audit Python | Lulus; bukan pengujian firewall/kernel |

Rangkaian akhir pada instalasi uji menghasilkan 7/7 tahap PASS: unit/import/UI, voice/CapCut, languages, alignment/camera, subtitle modes, matching, dependencies. Audio/video divalidasi lewat pembacaan sampel, FFprobe dan decode FFmpeg; ini tidak menggantikan penilaian kualitas oleh pendengar manusia.

Kegagalan awal diperbaiki: requirements lama berbeda dari versi terpasang; fixture subtitle lama tidak ikut distribusi sehingga runner kini membuat fixture dalam urutan yang benar; jumlah tab lama diperbarui ke tujuh; matching diulang setelah unduhan model selesai. Tes lokal dalam pembatasan jaringan sempat tertahan dan dijalankan ulang dengan akses loopback yang sesuai. Hasil akhir di atas berasal dari eksekusi yang selesai.

## Belum selesai / batas distribusi

- **Belum diuji pada Windows bersih atau komputer lain.** Tidak tersedia Windows Sandbox/VM yang siap dipakai dalam sesi ini. Instalasi baru pada komputer pengembang tetap tidak memenuhi syarat tersebut. Ikuti tests/CLEAN_WINDOWS.md sebelum persetujuan publikasi.
- Installer belum memiliki tanda tangan sertifikat penerbit; jangan menonaktifkan antivirus untuk memaksa instalasi.
- Runtime kompatibilitas Python 3.11.9 bukan patch keamanan terbaru. Pembaruan runtime dan pengujian ulang diperlukan sebelum rilis stabil.
- Uninstall/reinstall di Windows bersih, ketahanan unduhan yang diputus, antivirus lain, ARM64 dan variasi perangkat keras belum disertifikasi.
- TTS Indonesia otomatis tidak disertakan. Alignment kata Indonesia tidak dijanjikan. GPU/CUDA dan akurasi AI tidak dijamin.
- Lisensi kode GPL-3.0-only perlu ditinjau pemilik sebelum publikasi. Lisensi model/suara/dependensi tetap terpisah; tidak ada jaminan hak komersial universal atas media/hasil.

Tidak ada unggahan GitHub, Threads, atau publikasi file yang dilakukan. ZIP memakai daftar file yang diizinkan; runtime, cache, proyek, media, log, riwayat Git dan kredensial tidak disertakan. Pemeriksaan pola rahasia/path merupakan pemeriksaan tambahan, bukan klaim audit keamanan menyeluruh.
