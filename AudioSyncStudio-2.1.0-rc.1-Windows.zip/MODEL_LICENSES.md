# Lisensi model, terpisah dari kode aplikasi

Peninjauan: 30 Oktober 2026. Model tidak dibundel dalam installer/source ZIP. Persiapan mengunduh berkas dari repositori asal pada revisi dan SHA-256 di models.json; deklarasi upstream tidak digantikan oleh lisensi aplikasi.

| Komponen | Bukti upstream | Keputusan/batas |
|---|---|---|
| Kokoro-82M v1 + suara Inggris dari repo yang sama | https://huggingface.co/hexgrad/Kokoro-82M ; kartu menyatakan Apache-2.0 | Diunduh langsung. Simpan atribusi kartu/model. Tidak menjamin hak publisitas/persetujuan setiap identitas suara atau semua data pelatihan. |
| OpenAI CLIP ViT-B/32 | https://github.com/openai/CLIP/blob/main/LICENSE ; https://huggingface.co/openai/clip-vit-base-patch32 | MIT; pertahankan pemberitahuan hak cipta. Tidak menjamin kecocokan gambar. |
| clip-ViT-B-32-multilingual-v1 | https://huggingface.co/sentence-transformers/clip-ViT-B-32-multilingual-v1 | Apache-2.0 deklarasi model; menggunakan multilingual DistilBERT dan distilasi CLIP. Revisi dipatok. |
| en_core_web_sm 3.8.0 | https://github.com/explosion/spacy-models/releases/tag/en_core_web_sm-3.8.0 | MIT; komponen bahasa untuk pelafalan Inggris, bukan suara Indonesia. |
| PocketSphinx model Inggris bawaan paket | https://github.com/cmusphinx/pocketsphinx | Pertahankan lisensi/notice paket; hanya dipakai alignment Inggris. |

Kartu asli dan lisensi CLIP disimpan di licenses/. Tidak ada Piper Indonesia, Chatterbox Indonesia, MMS nonkomersial, atau fallback TTS Indonesia tersembunyi. Audio Indonesia berasal dari pengguna, yang bertanggung jawab atas izin rekamannya.

Apache/MIT mengizinkan penggunaan termasuk komersial dengan ketentuannya, tetapi itu bukan jaminan tanpa batas atas hak pihak ketiga atau monetisasi setiap hasil. Sebelum membundel ulang bobot atau suara, lakukan pemeriksaan redistribusi khusus. Kandidat ini memakai unduhan upstream, bukan menawarkan hak redistribusi baru.
