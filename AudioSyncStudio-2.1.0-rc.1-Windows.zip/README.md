# AudioSync Studio 2.1.0-rc.1

**Kandidat rilis untuk ditinjau. Belum disetujui untuk dibagikan.** Aplikasi Windows lokal untuk membuat narasi Inggris, memasangkan gambar dengan skrip, menyinkronkan scene, dan mengekspor video serta media CapCut. Baca [status pengujian](RELEASE_STATUS.md) sebelum distribusi.

## Instalasi tanpa mengatur Python

1. Ekstrak paket rilis dan jalankan `AudioSyncStudio-Setup.exe`.
2. Pilih lokasi baru. Jangan pilih folder instalasi pribadi atau versi lain.
3. Buka persiapan komponen di akhir installer. Baca lisensi lalu ketik `SETUJU`.
4. Tunggu unduhan Python privat, paket, FFmpeg, serta model selesai. Internet diperlukan; tidak perlu akun atau API key.
5. Buka ikon **AudioSync Studio Public**. Aplikasi tampil di browser lokal.

Jika koneksi putus, jalankan **Setup Components** lagi. Berkas komponen dan model yang lolos SHA-256 dipakai kembali. Jika checksum tidak cocok, persiapan berhenti: jangan mematikan pemeriksaan keamanan.

## Kebutuhan

- Target: Windows 11 x64, RAM 16 GB, prosesor modern. ARM64 dan Windows 10 belum disertifikasi.
- CPU menjadi jalur standar; GPU tidak wajib. Jangan mengharapkan akselerasi CUDA dari paket CPU.
- Siapkan setidaknya 12 GB kosong untuk komponen, cache unduhan dan model, ditambah ruang proyek/video. Rendering 100–200 scene memerlukan ruang lebih besar dan waktu bergantung CPU.
- Unduhan awal perkiraan 2–4 GB (bukan ukuran installer). Model pencocokan sekitar 1,1 GB; Kokoro sekitar 330 MB ditambah suara. Ukuran pasti model tercatat di `models.json`; versi/hash komponen di `components.json` dan `requirements-lock.txt`.
- Installer ini menggunakan Python embedded 3.11.9 untuk kompatibilitas. Ini bukan patch keamanan Python terbaru; pembaruan runtime dan pengujian ulang diperlukan sebelum rilis stabil.

## Fitur dan batasan

- Inggris: Kokoro lokal, preview, pengaturan kecepatan dan regenerasi per kalimat.
- Indonesia: impor WAV/MP3 per kalimat. Tidak ada TTS Indonesia otomatis yang disertakan.
- AI Scene Matching: pencocokan global satu gambar per scene untuk Inggris/Indonesia; hasil tidak dijamin benar. Tinjau hasil meragukan dan konfirmasi urutan sebelum ekspor.
- Kamera lembut untuk gambar, timeline mengikuti audio; MP4 sumber tidak diberi gerakan gambar otomatis.
- Subtitle: tidak ada (default), file terpisah, atau dibakar ke video. Kelompok frasa/kalimat/kata; alignment Inggris bisa gagal dan memakai fallback berlabel. Indonesia memakai fallback kalimat, bukan alignment kata akurat.
- Ekspor 1080p 30 FPS H.264, WAV, timeline; CapCut mendapat scene MP4 tanpa narasi, narasi kontinu, preview dan subtitle sesuai pilihan. **Bukan format proyek native CapCut.**

## Data dan offline

Data ada di `%LOCALAPPDATA%\AudioSyncStudioData`: proyek, media, cache model, log lokal dan ekspor. Program terpisah di folder pilihan installer. Tidak ada path pengembang atau proyek pribadi dalam rilis. Variabel `AUDIOSYNC_DATA` dapat menunjuk folder data alternatif sebelum membuka launcher.

Setelah persiapan lengkap, TTS dan pencocokan memakai model lokal; rendering dan impor berjalan offline. Model yang hilang tidak diunduh diam-diam saat aplikasi berjalan: jalankan Setup Components dengan internet. Tidak perlu Codex atau ChatGPT terbuka; pemakaian aplikasi tidak memakai kuota Codex. Tidak ada panggilan API berbayar. Pengunduhan awal menghubungi Python.org, PyPI, GitHub, Hugging Face, dan penyedia build FFmpeg.

Tutup server melalui **Stop AudioSync Studio**; menutup tab browser saja tidak menghentikannya. Uninstall mempertahankan data/model dan runtime yang diunduh agar tidak menghapus pekerjaan Anda. Penghapusan data harus dilakukan sendiri setelah backup.

## Sumber dan lisensi

Kode aplikasi asli: GPL-3.0-only, lihat [LICENSE](LICENSE). Lisensi ini memungkinkan penggunaan dan berbagi gratis; distribusi perubahan wajib mematuhi GPL. Model, suara, rekaman pengguna, FFmpeg, Python dan paket memiliki lisensi masing-masing: [MODEL_LICENSES.md](MODEL_LICENSES.md), [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md). Lisensi aplikasi bukan jaminan hak atas wajah, suara, gambar, musik, atau monetisasi hasil.

Pengembang dapat menjalankan `Setup Components.bat` dari checkout baru, kemudian `start.bat`. Daftar inti ada di requirements.txt; installer memakai requirements-lock.txt (artefak Windows Python 3.11 dengan hash). Build: Inno Setup 7.1.1, `ISCC.exe installer.iss`. Distribusikan kode sumber versi yang sama bersama installer. Jangan sertakan runtime, data uji, kredensial, atau cache.
