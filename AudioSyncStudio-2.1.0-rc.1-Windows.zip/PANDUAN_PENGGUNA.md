# Panduan AudioSync Studio

## Mulai

Pasang lewat AudioSyncStudio-Setup.exe, jalankan persiapan komponen, lalu buka ikon AudioSync Studio Public. Saat pertama kali, internet diperlukan. Tidak perlu memasang Python secara manual. Jika browser belum terbuka, tunggu persiapan selesai; jangan menekan ikon berulang kali.

## Membuat video

1. **Projects**: buat proyek dan beri nama.
2. **Script**: tempel skrip, satu kalimat per baris, lalu simpan. Satu baris adalah satu scene.
3. **Voice**: pilih English untuk narasi Kokoro. Pilih suara, dengarkan preview, atur kecepatan lalu buat narasi. Regenerasi hanya kalimat yang ingin diperbaiki. Untuk Indonesia, pilih Indonesian dan impor WAV/MP3 yang sesuai setiap kalimat; gunakan scene_001.wav, scene_002.wav, dan seterusnya. Pastikan Anda berhak menggunakan rekamannya.
4. **Scenes**: masukkan gambar/video bernomor melalui folder, ZIP, atau unggahan. Untuk nama acak, buka **AI Scene Matching** dan masukkan gambar. Jalankan pencocokan, tinjau setiap pasangan, ganti/tukar yang salah, tandai hasil meragukan setelah ditinjau, lalu klik **Confirm Scene Order**. Video diimpor melalui Scenes.
5. **Timeline**: cek preview dan urutan. Durasi mengikuti narasi; Anda dapat menambah jeda atau durasi. Pilih gerakan kamera gambar bila diinginkan.
6. **Subtitles**: pilih No Subtitles jika tidak dibutuhkan. Export Subtitle Separately membuat SRT/ASS tanpa membakar teks ke video. Burn Subtitles into Video menambahkan teks pada MP4/preview dan membuat SRT. Periksa teks dan timing; fallback kalimat berarti kata belum berhasil disejajarkan secara akustik.
7. **Export**: render video penuh atau Export for CapCut. Tunggu indikator selesai. Buka hasil untuk mengecek gambar, suara dan subtitle sebelum dipublikasikan.

## Melanjutkan di CapCut

Ekstrak ZIP ekspor. Impor scene_001.mp4 dan seterusnya menurut nomor. Tambahkan narration.wav sebagai satu track kontinu. Impor subtitles.srt jika diekspor. Scene MP4 sengaja tanpa narasi agar suara tidak dobel. final_preview.mp4 adalah pratinjau hasil lengkap. Ini media standar, bukan proyek CapCut otomatis.

## Menyimpan dan menutup

Kemajuan tersimpan per kalimat. Pilih proyek yang sama untuk melanjutkan; audio valid digunakan lagi. Jika skrip diubah, regenerasi atau impor ulang audio kalimat terkait. Backup seluruh folder proyek, bukan hanya project.json. Buka folder data melalui `%LOCALAPPDATA%\AudioSyncStudioData` di File Explorer.

Setelah pekerjaan selesai, jalankan Stop AudioSync Studio. Jangan menghentikan aplikasi saat rendering. Jangan menghapus cache/model ketika sedang dipakai.

## Mengatasi masalah

- Model/paket belum siap: tutup aplikasi, hubungkan internet dan jalankan Setup Components lagi.
- Memori rendah: tutup aplikasi berat lain, gunakan CPU, proses satu proyek bergantian.
- Hasil matching salah: gunakan penggantian manual. Skor bukan probabilitas kebenaran.
- Video tanpa subtitle: cek pilihan No Subtitles/Separate; ini memang tidak membakar teks.
- Windows memberi peringatan: paket kandidat belum memiliki tanda tangan penerbit. Verifikasi sumber dan SHA-256; jangan mematikan antivirus.
- Jangan mengunggah log/proyek pribadi ke forum secara terbuka. Log bisa berisi nama file atau isi kesalahan.
