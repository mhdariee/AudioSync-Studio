# Komponen pihak ketiga

AudioSync Studio source: Copyright 2026 AudioSync Studio contributors. GPL-3.0-only. LICENSE berlaku untuk kode aplikasi asli, bukan mengubah lisensi komponen/model. Pilihan GPL menjaga distribusi kode terbuka dan kompatibilitas komponen phonemizer/eSpeak yang copyleft. Mohon tinjau pilihan lisensi ini sebelum menyetujui publikasi.

- Python: PSF license dan notice pustaka bawaan, https://docs.python.org/3/license.html. ZIP embedded resmi diunduh langsung, LICENSE.txt dipertahankan di runtime. Python 3.11.9 bukan patch keamanan terbaru; ini keterbatasan kandidat.
- FFmpeg Gyan essentials 9.0.2: build GPL (termasuk libx264), https://www.gyan.dev/ffmpeg/builds/ dan https://ffmpeg.org/legal.html. Installer mengunduh arsip upstream dengan SHA-256; license/docs arsip dipertahankan. Tidak ada binary FFmpeg di ZIP publik. Jangan mengemas ulang binary sendiri tanpa menyediakan corresponding source yang sesuai beserta komponen/build scripts yang diwajibkan. Link sumber FFmpeg saja belum tentu cukup untuk seluruh build.
- Kokoro/Misaki: Apache-2.0. eSpeak NG/phonemizer dan dependensinya memiliki ketentuan GPL masing-masing; tidak boleh dilabeli MIT hanya karena aplikasi gratis.
- Streamlit: Apache-2.0; NumPy/Pandas/PyTorch memiliki lisensi BSD dan notice masing-masing; SoundFile BSD serta libsndfile LGPL; Pillow HPND; Transformers Apache-2.0; safetensors Apache-2.0. Ikuti metadata dan berkas lisensi versi yang dipasang, bukan ringkasan ini saja.
- Installer dibangun dengan Inno Setup 7.1.1, Copyright Jordan Russell/Martijn Laan, https://jrsoftware.org/. Notice compiler ada di licenses/inno-license.txt. Ini rilis gratis nonkomersial; distribusi komersial perlu meninjau ketentuan Inno terkini.
- Daftar artefak dependency dengan versi, URL, hash dan metadata lisensi ada di licenses/dependencies.json. Metadata UNKNOWN/kosong bukan izin: lihat berkas lisensi upstream sebelum membundel ulang paket. Kandidat ini memasang paket dari sumber upstream, bukan menyalin virtualenv pengembang.
- Lisensi model dan suara dijelaskan terpisah dalam MODEL_LICENSES.md. Ikon AudioSync Studio adalah aset geometris aplikasi; tidak memakai logo CapCut/YouTube/OpenAI sebagai merek aplikasi.

Pemasangan pertama hanya dengan persetujuan pengguna; tidak meminta API key dan tidak mengirim skrip/media untuk sintesis. Koneksi unduhan tetap mengungkap IP dan metadata permintaan normal ke penyedia file. Tidak ada jaminan hak atas media pengguna atau keluaran AI.
